#!/usr/bin/env python3
"""Cierres, claves candidatas, cubrimiento mínimo y equivalencia de conjuntos de DF.

Uso:
    python3 dependencias.py F-ecodata.txt              # cierres, claves y cubrimiento mínimo
    python3 dependencias.py F-ecodata.txt G-otro.txt   # además, equivalencia entre F y G

Formato del archivo de entrada: ver F-ecodata.txt. Las dependencias se pueden escribir
con las letras declaradas en "atributos:" o con los nombres de columna. Para comparar dos
archivos, ambos deben usar los mismos nombres de tabla y de columna (las letras pueden variar).
"""
import sys
from itertools import combinations


def leer(ruta):
    tablas, actual = {}, None
    with open(ruta, encoding="utf-8") as f:
        for linea in f:
            texto, _, comentario = linea.partition("#")
            texto, comentario = texto.strip(), comentario.strip()
            if not texto:
                continue
            if texto.startswith("[") and texto.endswith("]"):
                actual = {"orden": [], "letra": {}, "nombre": {}, "df": []}
                tablas[texto[1:-1].strip()] = actual
            elif texto.lower().startswith("atributos:"):
                for par in texto.split(":", 1)[1].split():
                    letra, _, nombre = par.partition("=")
                    nombre = nombre or letra
                    actual["orden"].append(nombre)
                    actual["letra"][nombre] = letra
                    actual["nombre"][letra] = nombre
                    actual["nombre"][nombre] = nombre
            else:
                izq, _, der = texto.partition("->")
                a = frozenset(actual["nombre"][x] for x in izq.split())
                b = frozenset(actual["nombre"][x] for x in der.split())
                actual["df"].append((a, b, comentario))
    return tablas


def cierre(x, deps, traza=None):
    resultado = set(x)
    cambio = True
    while cambio:
        cambio = False
        for a, b, *_ in deps:
            if a <= resultado and not b <= resultado:
                nuevos = b - resultado
                resultado |= b
                cambio = True
                if traza is not None:
                    traza.append((a, nuevos, set(resultado)))
    return resultado


class Tabla:
    def __init__(self, nombre, datos):
        self.nombre, self.orden = nombre, datos["orden"]
        self.letra, self.df = datos["letra"], datos["df"]
        self.todos = set(self.orden)

    def s(self, conjunto):
        """Conjunto de columnas -> cadena de letras en el orden de la tabla."""
        return "".join(self.letra[c] for c in self.orden if c in conjunto) or "∅"

    def d(self, a, b):
        return f"{self.s(a)} → {self.s(b)}"

    def mostrar_cierre(self, x, deps):
        traza = []
        r = cierre(x, deps, traza)
        pasos = [f"{{{self.s(x)}}}"]
        for a, nuevos, acumulado in traza:
            pasos.append(f"por {self.s(a)} → … se agrega {self.s(nuevos)}: {{{self.s(acumulado)}}}")
        return r, pasos

    def claves(self):
        izq = set().union(*(a for a, _, _ in self.df)) if self.df else set()
        der = set().union(*(b for _, b, _ in self.df)) if self.df else set()
        solo_izq = izq - der
        solo_der = der - izq
        ambos = izq & der
        ninguno = self.todos - izq - der
        nucleo = solo_izq | ninguno
        print(f"  Solo a la izquierda: {self.s(solo_izq)} · solo a la derecha: {self.s(solo_der)}"
              f" · en ambos lados: {self.s(ambos)} · en ninguno: {self.s(ninguno)}")
        print(f"  Núcleo (está en toda clave): {{{self.s(nucleo)}}}")
        encontradas = []
        candidatos = sorted(ambos, key=self.orden.index)
        for k in range(0, len(candidatos) + 1):
            for extra in combinations(candidatos, k):
                x = nucleo | set(extra)
                if not x or any(c <= x for c in encontradas):
                    continue
                r, pasos = self.mostrar_cierre(x, self.df)
                completo = r == self.todos
                print(f"  {{{self.s(x)}}}⁺ = {{{self.s(r)}}}" + ("  ← clave candidata" if completo else ""))
                for p in pasos[1:]:
                    print(f"      {p}")
                if completo:
                    encontradas.append(x)
        print("  Claves candidatas: " + ", ".join("{" + self.s(c) + "}" for c in encontradas))
        return encontradas

    def minimo(self):
        # Paso 1: lados derechos simples.
        g = []
        for a, b, com in self.df:
            for c in sorted(b, key=self.orden.index):
                g.append((a, frozenset([c]), com))
        print("  Paso 1, lados derechos simples: " + "; ".join(self.d(a, b) for a, b, _ in g))
        # Paso 2: atributos sobrantes a la izquierda.
        print("  Paso 2, atributos sobrantes a la izquierda:")
        nuevo = []
        hubo = False
        for i, (a, b, com) in enumerate(g):
            if len(a) > 1:
                hubo = True
                actual = set(a)
                for x in sorted(a, key=self.orden.index):
                    resto = actual - {x}
                    if not resto:
                        continue
                    r = cierre(resto, g)
                    sobra = b <= r
                    print(f"    {self.d(a, b)}: ¿sobra {self.letra[x]}? {{{self.s(resto)}}}⁺ = {{{self.s(r)}}}"
                          + (f" contiene {self.s(b)} → sí, se elimina" if sobra else f" no contiene {self.s(b)} → no"))
                    if sobra:
                        actual = resto
                nuevo.append((frozenset(actual), b, com))
            else:
                nuevo.append((a, b, com))
        if not hubo:
            print("    No hay lados izquierdos compuestos.")
        # Quitar duplicados conservando el orden.
        g, vistos = [], set()
        for a, b, com in nuevo:
            if (a, b) not in vistos:
                vistos.add((a, b))
                g.append((a, b, com))
        # Paso 3: dependencias redundantes. Primero las que no salen de la clave primaria.
        pk = {self.orden[0]}
        orden = [d for d in g if d[0] != pk] + [d for d in g if d[0] == pk]
        print("  Paso 3, dependencias redundantes (se prueban primero las que no salen de la clave primaria):")
        for dep in orden:
            a, b, com = dep
            sin = [d for d in g if d is not dep]
            r = cierre(a, sin)
            redundante = b <= r
            print(f"    {self.d(a, b)}: {{{self.s(a)}}}⁺ sin ella = {{{self.s(r)}}}"
                  + (" → redundante, se elimina" if redundante else " → se conserva"))
            if redundante:
                g = sin
        print("  Cubrimiento mínimo: " + "; ".join(self.d(a, b) for a, b, _ in g))
        return g


def implica(t, deps, otras):
    ok = True
    for a, b, _ in otras:
        r = cierre(a, deps)
        bien = b <= r
        ok &= bien
        print(f"      {t.d(a, b)}: {{{t.s(a)}}}⁺ = {{{t.s(r)}}} → {'se deduce' if bien else 'NO se deduce'}")
    return ok


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    f = leer(sys.argv[1])
    print("=" * 70)
    print(f"Archivo: {sys.argv[1]}")
    for nombre, datos in f.items():
        t = Tabla(nombre, datos)
        print("=" * 70)
        print(f"{nombre}(" + ", ".join(f"{t.letra[c]}={c}" for c in t.orden) + ")")
        print("F = " + ("; ".join(t.d(a, b) for a, b, _ in t.df) or "∅ (solo dependencias triviales)"))
        t.claves()
        if t.df:
            minimo = t.minimo()
            print("  Comprobación F ≡ Fmin: toda DF de F se deduce de Fmin")
            implica(t, minimo, t.df)
    if len(sys.argv) > 2:
        g = leer(sys.argv[2])
        print("=" * 70)
        print(f"Equivalencia entre {sys.argv[1]} (F) y {sys.argv[2]} (G)")
        for nombre in sorted(set(f) | set(g)):
            if nombre not in f or nombre not in g:
                print(f"  {nombre}: solo aparece en uno de los dos archivos → no se puede comparar")
                continue
            t = Tabla(nombre, f[nombre])
            otra = g[nombre]["df"]
            print(f"  {nombre}:")
            print("    ¿F cubre a G?")
            a = implica(t, t.df, otra)
            print("    ¿G cubre a F?")
            b = implica(t, otra, t.df)
            print(f"    Resultado: {'EQUIVALENTES' if a and b else 'NO equivalentes'}")


if __name__ == "__main__":
    main()
